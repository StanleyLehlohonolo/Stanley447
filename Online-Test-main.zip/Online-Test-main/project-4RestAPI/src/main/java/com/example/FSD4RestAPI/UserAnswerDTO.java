package com.example.FSD4RestAPI;

//UserAnswerDTO.java
public class UserAnswerDTO {
 private Long questionId;
 private String answer;
public Long getQuestionId() {
	return questionId;
}
public void setQuestionId(Long questionId) {
	this.questionId = questionId;
}
public String getAnswer() {
	return answer;
}
public void setAnswer(String answer) {
	this.answer = answer;
}

 // Getters and setters
}
