package com.example.FSD4RestAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Fsd4RestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
